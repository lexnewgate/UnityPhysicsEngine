#include <iostream>
#include <cstdio>
#include "vectors.h"

int main(int argc, char** argv) {
	std::cout << "Press return to exit...";

	getchar();

	return 0;
}