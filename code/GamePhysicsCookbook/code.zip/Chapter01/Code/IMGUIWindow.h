#ifndef _H_IMGUI_WINDOW_
#define _H_IMGUI_WINDOW_

// TODO: Implement DearImgui as a standard, sub-classable window
// url: https://github.com/ocornut/imgui

#include "GLWindow.h"

#endif
